/******************************************************************************************************
LIST SCRIPT
******************************************************************************************************/
var app = new Vue({
    el: '#app',
    data: {
        newItem: '',
        items: [{
            text: 'Bananas',
            checked: true
						}, {
            text: 'Apples',
            checked: false
						}],
        title: 'My Shopping List'
    },
    methods: {
        addItem: function () {
            var text;
            text = this.newItem.trim();
            if (text) {
                this.items.push({
                    text: text,
                    checked: false
                });
                this.newItem = '';
            }
        }
    }
});

/******************************************************************************************************
DAY SCRIPT
******************************************************************************************************/
var app2 = new Vue({
    el: '#app2',
    data: {
        newItem: '',
        items: [{
            text: 'Yes',
            checked: true
                    }, {
            text: 'Wake up',
            checked: false
                    }],
        title: ''
    },
    methods: {
        addItem: function () {
            var text;
            text = this.newItem.trim();
            if (text) {
                this.items.push({
                    text: text,
                    checked: false
                });
                this.newItem = '';
            }
        }
    }
});
